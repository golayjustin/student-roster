#pragma once
enum DegreeProgram {SECURITY, NETWORK, SOFTWARE};
static string degreeProgramStrings[] = { "SECURITY", "NETWORK", "SOFTWARE" };